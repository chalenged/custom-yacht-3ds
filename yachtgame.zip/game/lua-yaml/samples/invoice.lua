return {
  ["bill-to"] = {
    ["address"] = {
      ["city"] = "Royal Oak",
      ["lines"] = "458 Walkman Dr.\
Suite #292",
      ["postal"] = 48046,
      ["state"] = "MI"
    },
    ["family"] = "Dumars",
    ["given"] = "Chris"
  },
  ["date"] = 980179200,
  ["invoice"] = 34843,
  ["ship-to"] = {
    ["address"] = {
      ["city"] = "Royal Oak",
      ["lines"] = "458 Walkman Dr.\
Suite #292",
      ["postal"] = 48046,
      ["state"] = "MI"
    },
    ["family"] = "Dumars",
    ["given"] = "Chris"
  }
}
