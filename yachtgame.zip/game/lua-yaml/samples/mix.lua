return {
  ["array"] = {
    [1] = "a",
    [2] = "b",
    [3] = "c"
  },
  ["false"] = false,
  ["number"] = 1,
  ["object"] = {
    ["key"] = "value"
  },
  ["text"] = "Text",
  ["text_number"] = "1",
  ["text_with_double_quote"] = "Text",
  ["text_with_single_quote"] = "Text",
  ["text_with_space"] = "Text text",
  ["true"] = true
}
