return {
  ["FIRST"] = {
    [1] = {
      ["dict"] = {
        ["value"] = 1
      },
      ["list"] = {
        [1] = {
          ["a"] = 1,
          ["b"] = 2,
          ["c"] = 3
        }
      }
    }
  },
  ["SECOND"] = "is missing"
}
