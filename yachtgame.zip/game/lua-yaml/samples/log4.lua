return {
  ["Date"] = 1006498997,
  ["Fatal"] = "Unknown variable \"bar\"",
  ["Stack"] = {
    [1] = {
      ["file"] = "TopClass.py\
line: 23\
code: |\
x = MoreObject(\"345\\n\")\
"
    },
    [2] = {
      ["code"] = "foo = bar",
      ["file"] = "MoreClass.py",
      ["line"] = 58
    }
  },
  ["User"] = "ed"
}
