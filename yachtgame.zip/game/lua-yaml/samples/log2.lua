return {
  ["Time"] = 1006498951,
  ["User"] = "ed",
  ["Warning"] = "A slightly different error\
message."
}
