return {
  ["Date"] = 1006498997,
  ["Fatal"] = "Unknown variable \"bar\"",
  ["Stack"] = {
    [1] = {
      ["code"] = "x = MoreObject(\"345\\n\")",
      ["file"] = "TopClass.py",
      ["line"] = 23
    },
    [2] = {
      ["code"] = "foo = bar",
      ["file"] = "MoreClass.py",
      ["line"] = 58
    }
  },
  ["User"] = "ed"
}
