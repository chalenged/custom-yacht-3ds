return {
  ["end"] = "test passed?",
  ["notnull"] = true,
  ["test"] = "A test for null values"
}
