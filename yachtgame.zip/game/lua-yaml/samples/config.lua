return {
  ["dbg-mode"] = false,
  ["pid"] = "/home/www/pids/thin.pid",
  ["port"] = 3000,
  ["require"] = {
  },
  ["servers"] = 2,
  ["timeout"] = 15,
  ["wait"] = 30
}
