return {
  ["brackets"] = {
    ["extrasquare"] = "[Scratch that] brackets can go at the beginning as long as they close and have text after.",
    ["extrasquiggle"] = "{Scratch that} squigs can go at the beginning also!",
    ["square"] = "Square [brackets] can go in the middle of strings",
    ["squiggle"] = "Squiggle {brackets} can also go in the middle of strings!"
  },
  ["country"] = {
    ["name"] = "Österreich",
    ["website"] = "http://en.wikipedia.org/wiki/Austria"
  },
  ["space"] = {
    ["description"] = "space, the final frontier"
  },
  ["users"] = {
    ["bob"] = {
      ["age"] = 27,
      ["name"] = "bob"
    },
    ["ted"] = {
      ["age"] = 32,
      ["email"] = "ted@tedtalks.com",
      ["name"] = "ted"
    },
    ["tj"] = {
      ["age"] = 23,
      ["email"] = "tj@vision-media.ca",
      ["name"] = "tj"
    }
  }
}
