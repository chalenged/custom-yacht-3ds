return {
  [1] = "lots of milk",
  [2] = "cookies",
  [3] = "something"
}
