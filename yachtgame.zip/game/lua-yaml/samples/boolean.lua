return {
  ["also"] = {
    [1] = "lists",
    [2] = "can",
    [3] = "say",
    [4] = true
  },
  ["falseme"] = "I can see this",
  ["hope"] = "to see this",
  ["say"] = true,
  ["title"] = "Some Title",
  ["to"] = {
    [1] = false,
    [2] = "and so on"
  },
  ["trueme"] = "found",
  ["what"] = false
}
