return {
  ["Time"] = 1006498902,
  ["User"] = "ed",
  ["Warning"] = "This is an error message\
for the log file"
}
