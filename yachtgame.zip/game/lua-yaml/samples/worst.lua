return {
  ["Name"] = {
    [1] = {
      ["testing"] = "val1"
    },
    [2] = {
      ["second"] = "val2"
    },
    [3] = {
      ["fourth"] = "val4\
can be different",
      ["third"] = "val3"
    },
    [4] = "then",
    [5] = {
      ["final"] = "a\
aa\
aaa\
aaaa : 'test:'"
    }
  }
}
