return
{
    left       = "button:dpleft",
    right      = "button:dpright",
    up         = "button:dpup",
    down       = "button:dpdown",
    a          = "axis:leftx-",
    d          = "axis:leftx+",
    w          = "axis:lefty-",
    s          = "axis:lefty+",
    j          = "axis:rightx-",
    l          = "axis:rightx+",
    i          = "axis:righty-",
    k          = "axis:righty+",
    q          = "button:leftshoulder",
    e          = "button:rightshoulder",
    z          = "button:a",
    x          = "button:b",
    c          = "button:x",
    v          = "button:y",
    ["return"] = "button:start",
    rshift     = "button:select",
    ["1"]      = "axis:lefttrigger+",
    ["2"]      = "axis:righttrigger+",

    --special
    tab = "button:special"
}
